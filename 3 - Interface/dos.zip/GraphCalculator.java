// NIM		: 18221171
// Nama		: Hans Stephano E
// Tanggal	: 14 Februari 2023
// Topik	: Interface
// Deskripsi: Grouped Interface: Calculator, GraphUpgrade

public interface GraphCalculator extends Calculator, GraphUpgrade {
	
}
