public class CarWorkshop {
    public void changeTyre(Car car, Tyre tyre) {
        // Mengganti ban mobil
        car.setTyre(tyre);
    }

    public void changeEngine(Car car, Engine engine) {
        // Mengganti mesin mobil
        car.setEngine(engine);
    }
}
